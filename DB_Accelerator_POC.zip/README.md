
# DB Accelerator POC

## Features
- Upload ER Diagram
- OCR extraction
- SQL Server generation
- REST API preview
- Data dictionary
- Enterprise dark UI

---

## Setup

### Install dependencies
```bash
pip install -r requirements.txt
```

### Run
```bash
streamlit run app.py
```

---

## Optional OCR Setup (Windows)

Install Tesseract OCR:

https://github.com/UB-Mannheim/tesseract/wiki

Then add:

```python
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
```

