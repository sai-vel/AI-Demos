
# 🚀 DB Accelerator POC

AI-powered ER Diagram → SQL Server Generator built using Streamlit.

---

# ✨ Features

✅ Upload ER Diagram Images  
✅ OCR-based Schema Detection  
✅ SQL Server Script Generation  
✅ REST API Endpoint Preview  
✅ Data Dictionary Generation  
✅ Modern Enterprise UI  
✅ Download Generated SQL  

---

# 🖼 Application Screenshot

![Dashboard Preview](dashboard_preview.png)

---

# 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Streamlit |
| OCR | Tesseract |
| Backend | Python |
| Database | SQL Server |
| AI Ready | OpenAI Compatible |

---

# ▶ Run Locally

## 1. Install Dependencies

```bash
pip install -r requirements.txt
```

## 2. Run Application

```bash
streamlit run app.py
```

---

# 📦 Sample Use Cases

- Banking modernization
- Legacy migration
- Database reverse engineering
- Rapid backend prototyping
- Documentation automation

---

# 🔮 Future Enhancements

- OpenAI-powered schema intelligence
- API auto-generation
- Swagger integration
- Multi-database support
- Azure deployment

---

# ❤️ Built With

- Streamlit
- Python
- OCR
- AI Concepts
